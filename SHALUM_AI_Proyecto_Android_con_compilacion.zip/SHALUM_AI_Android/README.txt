SHALUM AI - PROYECTO ANDROID
============================

Este es el proyecto fuente de una aplicación Android nativa (contenedor WebView)
que abre SHALUM AI desde archivos locales del propio APK. No necesita Netlify,
internet ni cuenta para funcionar.

FUNCIONES:
- Inicio y accesos rápidos.
- Catálogo de servicios de SHALUM PLUS.
- Registro de clientes y datos de sus equipos.
- Diagnóstico preliminar orientativo según el síntoma seleccionado.
- Historial local y exportación de respaldo JSON.

IMPORTANTE:
- Los datos se guardan en el almacenamiento local de la aplicación en ese teléfono.
- No hay sincronización en la nube.
- El diagnóstico es orientación inicial, no una prueba automática del hardware.
- No almacenes datos sensibles de clientes en esta versión de demostración.
- Este ZIP contiene el CÓDIGO FUENTE, no un APK ya compilado.

CÓMO GENERAR EL APK:
1. En una computadora, instala Android Studio.
2. Abre Android Studio > Open y selecciona la carpeta SHALUM_AI_Android.
3. Espera a que Gradle sincronice y descargue las herramientas necesarias.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Al terminar, Android Studio mostrará la ubicación del APK generado.
6. Copia el APK al celular Android, ábrelo y permite instalar aplicaciones desde esa fuente.

Requisitos de compilación: Android Studio reciente, JDK 17 y Android SDK API 35.
Paquete: com.shalumplus.shalumai
Versión: 1.0
